package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class ItemPedidoTest {
    @ParameterizedTest @CsvSource({"0,1,0,1", "1000001,1,0,1", "1,-1,0,1", "1,101,0,1", "1,1,-1,1", "1,1,0,0", "1,1,0,100001"})
    void limitesInvalidos(long preco,int qtd,int estoque,int peso) {
        assertThrows(IllegalArgumentException.class, () -> new ItemPedido("A",preco,qtd,estoque,peso,false));
    }
    @Test void skuInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new ItemPedido(null,1,0,0,1,false));
        assertThrows(IllegalArgumentException.class, () -> new ItemPedido(" \t",1,0,0,1,false));
    }
    @Test void limitesValidosECalculos() {
        ItemPedido i=new ItemPedido("A",1000000,100,100,100000,true);
        assertEquals(100000000L,i.totalCentavos()); assertTrue(i.disponivel());
        assertEquals("A",i.sku()); assertEquals(1000000,i.precoCentavos()); assertEquals(100,i.estoque());
        assertEquals(100,i.quantidade()); assertEquals(100000,i.pesoGramas()); assertTrue(i.fragil());
        ItemPedido zero=new ItemPedido("B",1,0,0,1,false);
        assertEquals(0,zero.totalCentavos()); assertTrue(zero.disponivel());
        assertFalse(new ItemPedido("C",1,1,0,1,false).disponivel());
        assertTrue(new ItemPedido("D",1,1,2,1,false).disponivel());
    }
}
