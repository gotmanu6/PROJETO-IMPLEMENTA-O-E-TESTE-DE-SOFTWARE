package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class CalculadoraFreteTest {
    @ParameterizedTest @CsvSource({
        "PR,2000,29999,false,false,false,1200", "SP,1000,0,false,false,false,2000",
        "RJ,1000,0,false,false,false,2000", "ZZ,1000,0,false,false,false,3000",
        "PR,1999,0,false,false,false,1200", "PR,2001,0,false,false,false,1500",
        "PR,3000,0,false,false,false,1500", "PR,3001,0,false,false,false,1800",
        "PR,4500,0,false,false,false,2100", "PR,4500,30000,false,false,false,0",
        "PR,4500,30001,false,true,true,500", "PR,4500,30000,true,true,true,3050",
        "PR,1000,0,false,true,false,600", "PR,1000,0,true,false,false,2700",
        "PR,1000,0,false,false,true,1700"
    })
    void tarifasELimites(String uf,int peso,long liquido,boolean expresso,boolean vip,boolean fragil,long esperado) {
        Pedido p=new Pedido(List.of(new ItemPedido("A",100,1,1,peso,fragil)),uf,expresso,null);
        assertEquals(esperado,new CalculadoraFrete().calcular(p,new Cliente(vip,false,1),liquido));
    }
    @Test void fragilidadeCobradaUmaVez() {
        ItemPedido ativo=new ItemPedido("A",100,1,1,1,true);
        Pedido p=new Pedido(List.of(ativo,ativo),"PR",false,null);
        assertEquals(1700,new CalculadoraFrete().calcular(p,new Cliente(false,false,1),0));
    }
    @Test void rejeitaLiquidoNegativo() {
        assertThrows(IllegalArgumentException.class, () -> new CalculadoraFrete().calcular(new Pedido(List.of(),"PR",false,null),new Cliente(false,false,1),-1));
    }
}
