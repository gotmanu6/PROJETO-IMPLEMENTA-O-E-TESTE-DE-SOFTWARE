package br.edu.ifpr.boletim;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class ParticipacaoTest {
    @ParameterizedTest @CsvSource({"true,true,3", "true,false,2", "false,true,1", "false,false,0"})
    void quatroCaminhos(boolean entregou, boolean participou, int esperado) {
        assertEquals(esperado, new Participacao().calcularPontos(entregou, participou));
    }
}
