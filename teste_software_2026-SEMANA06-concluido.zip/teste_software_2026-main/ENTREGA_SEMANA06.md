# Entrega — SEMANA06

Os dois exercícios foram concluídos na cópia deste projeto.

| Projeto | Testes | Falhas/erros | Linhas | Branches | Métodos | Classes |
| --- | ---: | --- | --- | --- | --- | --- |
| boletim-simples | 19 | 0/0 | 100% | 100% | 100% | 100% |
| central-pedidos | 85 | 0/0 | 100% | 100% | 100% | 100% |

- [Relatório do Boletim](aulas/SEMANA06/boletim-simples/RELATORIO.md)
- [Relatório da Central: CFGs, McCabe, bases, matriz e discussões](aulas/SEMANA06/central-pedidos/RELATORIO.md)
- [JaCoCo do Boletim](aulas/SEMANA06/boletim-simples/target/site/jacoco/index.html)
- [JaCoCo da Central](aulas/SEMANA06/central-pedidos/target/site/jacoco/index.html)

Extraia todo o ZIP antes de abrir os HTMLs, para preservar estilos e links. Os CFGs estão em Mermaid e também têm rotas textuais e dados de nós/arestas. Use um visualizador Markdown com Mermaid para vê-los desenhados.

Para reproduzir, com JDK17+ e Maven3.9+, abra cada pasta de projeto e execute mvn clean test. A primeira execução pode baixar dependências. Não é necessário main, banco, rede de pagamento, Mockito ou IDE específica.

As mutações demonstrativas foram restauradas e ambas as execuções finais passaram. Logs de falhas em evidencias/mutacao.log são intencionais e históricos. Produção, pom.xml e demais aulas originais foram preservados.
