package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class PoliticaDescontoTest {
    private final PoliticaDesconto politica = new PoliticaDesconto();
    @ParameterizedTest @CsvSource(value={
        "false;1;0;NULL;0", "false;1;49999;NULL;0", "false;1;50000;NULL;2500",
        "false;1;50001;NULL;2500", "true;1;10009;NULL;1000", "false;1;50000;BRANCO;2500",
        "false;0;9999;BEMVINDO;0", "false;0;10000;BEMVINDO;2000", "false;0;10001;BEMVINDO;2000",
        "false;1;10000;BEMVINDO;0", "true;0;10000;BEMVINDO;2000",
        "false;1;19999;EXTRA10;0", "false;1;20000;EXTRA10;2000", "false;1;20001;EXTRA10;2000",
        "true;1;20009;EXTRA10;4000", "false;1;50001;EXTRA10;7500"
    }, delimiter=';')
    void regrasELimites(boolean vip, int compras, long subtotal, String cupom, long esperado) {
        if (cupom.equals("NULL")) cupom=null;
        else if (cupom.equals("BRANCO")) cupom=" \t ";
        assertEquals(esperado, politica.calcular(new Cliente(vip,false,compras), subtotal, cupom));
    }
    @Test void normalizaCupons() {
        assertEquals(2000, politica.calcular(new Cliente(false,false,0),10000," bemvindo "));
        assertEquals(2000, politica.calcular(new Cliente(false,false,1),20000," extra10 "));
    }
    @Test void rejeitaSubtotalECupom() {
        assertThrows(IllegalArgumentException.class, () -> politica.calcular(new Cliente(false,false,1),-1,null));
        assertThrows(IllegalArgumentException.class, () -> politica.calcular(new Cliente(false,false,1),10000,"ABC"));
    }
}
