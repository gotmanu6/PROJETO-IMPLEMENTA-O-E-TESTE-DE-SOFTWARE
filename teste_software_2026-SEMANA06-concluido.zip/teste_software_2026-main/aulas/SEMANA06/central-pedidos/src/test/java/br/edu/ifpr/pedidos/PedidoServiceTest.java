package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class PedidoServiceTest {
    private final Cliente comum=new Cliente(false,false,1);
    private Pedido pedido(long preco,int qtd,int estoque,boolean expresso,String cupom) {
        return new Pedido(List.of(new ItemPedido("A",preco,qtd,estoque,1000,false)),"PR",expresso,cupom);
    }
    private void resultado(ResultadoPedido r,String status,long subtotal,long desconto,long frete,long total) {
        assertAll(() -> assertEquals(status,r.status()), () -> assertEquals(subtotal,r.subtotalCentavos()),
            () -> assertEquals(desconto,r.descontoCentavos()), () -> assertEquals(frete,r.freteCentavos()),
            () -> assertEquals(total,r.totalCentavos()));
    }
    @ParameterizedTest @CsvSource({"true,PAGO", "false,PAGAMENTO_RECUSADO"})
    void pagamentoImediato(boolean aprovado,String status) {
        List<Long> chamadas=new ArrayList<>();
        ResultadoPedido r=new PedidoService(t -> {chamadas.add(t);return aprovado;}).fechar(pedido(10000,1,5,false,null),comum);
        resultado(r,status,10000,0,1200,11200); assertEquals(List.of(11200L),chamadas);
    }
    @Test void bloqueioAntesDeSubtotalEstoqueECupom() {
        List<Long> chamadas=new ArrayList<>(); PedidoService s=new PedidoService(t -> {chamadas.add(t);return true;});
        Cliente bloqueado=new Cliente(false,true,0);
        resultado(s.fechar(new Pedido(List.of(),"PR",false,"ABC"),bloqueado),"BLOQUEADO",0,0,0,0);
        resultado(s.fechar(pedido(10000,2,0,false,"ABC"),bloqueado),"BLOQUEADO",0,0,0,0);
        assertTrue(chamadas.isEmpty());
    }
    @Test void validacoesEInterrupcoesSemCobranca() {
        List<Long> chamadas=new ArrayList<>(); PedidoService s=new PedidoService(t -> {chamadas.add(t);return true;});
        assertThrows(NullPointerException.class, () -> new PedidoService(null));
        assertThrows(NullPointerException.class, () -> s.fechar(null,comum));
        assertThrows(NullPointerException.class, () -> s.fechar(pedido(1,1,1,false,null),null));
        assertThrows(NullPointerException.class, () -> s.fechar(null,new Cliente(false,true,0)));
        assertThrows(IllegalArgumentException.class, () -> s.fechar(new Pedido(List.of(),"PR",false,null),comum));
        assertThrows(IllegalArgumentException.class, () -> s.fechar(pedido(1,0,0,false,null),comum));
        assertThrows(IllegalArgumentException.class, () -> s.fechar(pedido(1,1,1,false,"ABC"),comum));
        assertTrue(chamadas.isEmpty());
    }
    @Test void estoqueAntesDoCupom() {
        List<Long> chamadas=new ArrayList<>();
        resultado(new PedidoService(t -> {chamadas.add(t);return true;}).fechar(pedido(10000,5,4,false,"ABC"),comum),"SEM_ESTOQUE",0,0,0,0);
        assertTrue(chamadas.isEmpty());
    }
    @Test void revisaoSemCobranca() {
        List<Long> chamadas=new ArrayList<>(); PedidoService s=new PedidoService(t -> {chamadas.add(t);return true;});
        resultado(s.fechar(pedido(200000,1,1,false,null),new Cliente(false,false,0)),"REVISAO",200000,10000,0,190000);
        resultado(s.fechar(pedido(10000,1,1,true,null),new Cliente(false,false,0)),"REVISAO",10000,0,2700,12700);
        resultado(s.fechar(pedido(600000,1,1,false,null),comum),"REVISAO",600000,30000,0,570000);
        assertTrue(chamadas.isEmpty());
    }
    @ParameterizedTest @CsvSource({"1,PAGO,2", "2,PAGO,3", "3,PAGAMENTO_RECUSADO,3"})
    void falhasTemporarias(int falhas,String status,int quantidade) {
        List<Long> chamadas=new ArrayList<>();
        PedidoService s=new PedidoService(t -> {chamadas.add(t);if(chamadas.size()<=falhas) throw new IllegalStateException();return true;});
        resultado(s.fechar(pedido(10000,1,1,false,null),comum),status,10000,0,1200,11200);
        assertEquals(Collections.nCopies(quantidade,11200L),chamadas);
    }
    @Test void propagaFalhaDoProcessador() {
        List<Long> chamadas=new ArrayList<>(); RuntimeException erro=new UnsupportedOperationException("erro");
        PedidoService s=new PedidoService(t -> {chamadas.add(t);throw erro;});
        assertSame(erro,assertThrows(UnsupportedOperationException.class, () -> s.fechar(pedido(10000,1,1,false,null),comum)));
        assertEquals(List.of(11200L),chamadas);
    }
    @Test void colaboracaoDescontoFreteEEntradasImutaveis() {
        Cliente vip=new Cliente(true,false,1);
        Pedido p=new Pedido(List.of(new ItemPedido("A",20009,2,2,1501,true)),"SP",true," extra10 ");
        List<Long> chamadas=new ArrayList<>(); PedidoService s=new PedidoService(t -> {chamadas.add(t);return true;});
        resultado(s.fechar(p,vip),"PAGO",40018,8002,3300,35316);
        resultado(s.fechar(p,vip),"PAGO",40018,8002,3300,35316);
        assertEquals(List.of(35316L,35316L),chamadas);
        assertEquals(2,p.itens().get(0).estoque()); assertEquals(1,vip.comprasAnteriores());
    }
}
