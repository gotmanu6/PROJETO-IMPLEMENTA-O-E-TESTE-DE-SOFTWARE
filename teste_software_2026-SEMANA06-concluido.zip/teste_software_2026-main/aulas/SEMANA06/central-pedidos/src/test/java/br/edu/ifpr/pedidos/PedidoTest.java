package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class PedidoTest {
    private ItemPedido item(int qtd,int estoque,boolean fragil) { return new ItemPedido("A",100,qtd,estoque,1000,fragil); }
    @Test void validaListaEUf() {
        assertThrows(IllegalArgumentException.class, () -> new Pedido(null,"PR",false,null));
        assertThrows(IllegalArgumentException.class, () -> new Pedido(Collections.nCopies(101,item(1,1,false)),"PR",false,null));
        assertThrows(NullPointerException.class, () -> new Pedido(Arrays.asList((ItemPedido)null),"PR",false,null));
        for(String uf : Arrays.asList(null,"","P","PRR","pr","P1","ÁB"))
            assertThrows(IllegalArgumentException.class, () -> new Pedido(List.of(),uf,false,null));
        assertEquals(100,new Pedido(Collections.nCopies(100,item(1,1,false)),"ZZ",false,null).itens().size());
    }
    @Test void copiaDefensiva() {
        List<ItemPedido> origem=new ArrayList<>(List.of(item(1,1,false)));
        Pedido p=new Pedido(origem,"PR",false,"EXTRA10"); origem.clear();
        assertEquals(1,p.itens().size());
        assertThrows(UnsupportedOperationException.class, () -> p.itens().clear());
        assertEquals("PR",p.uf()); assertFalse(p.expresso()); assertEquals("EXTRA10",p.cupom());
    }
    @Test void vazio() {
        Pedido p=new Pedido(List.of(),"PR",false,null);
        assertEquals(0,p.subtotalCentavos()); assertEquals(0,p.pesoGramas());
        assertFalse(p.temFragil()); assertTrue(p.estoqueSuficiente());
    }
    @Test void umaLinhaInativa() {
        Pedido p=new Pedido(List.of(item(0,0,true)),"PR",false,null);
        assertEquals(0,p.subtotalCentavos()); assertEquals(0,p.pesoGramas());
        assertFalse(p.temFragil()); assertTrue(p.estoqueSuficiente());
    }
    @Test void variasLinhasEContinue() {
        Pedido p=new Pedido(List.of(item(0,0,true),item(1,1,false),item(2,2,true),item(1,1,true)),"PR",false,null);
        assertEquals(400,p.subtotalCentavos()); assertEquals(4000,p.pesoGramas());
        assertTrue(p.temFragil()); assertTrue(p.estoqueSuficiente());
    }
    @Test void faltaEstoqueInicioEFimESkuRepetido() {
        ItemPedido ok=item(1,1,false), falta=item(2,1,false);
        assertFalse(new Pedido(List.of(falta,ok),"PR",false,null).estoqueSuficiente());
        assertFalse(new Pedido(List.of(ok,falta),"PR",false,null).estoqueSuficiente());
        assertTrue(new Pedido(List.of(ok,ok),"PR",false,null).estoqueSuficiente());
        assertFalse(new Pedido(List.of(ok),"PR",false,null).temFragil());
    }
    @Test void maximoDoDominioSemOverflow() {
        Pedido p=new Pedido(Collections.nCopies(100,new ItemPedido("A",1000000,100,100,100000,false)),"PR",false,null);
        assertEquals(10000000000L,p.subtotalCentavos()); assertEquals(1000000000,p.pesoGramas());
    }
}
