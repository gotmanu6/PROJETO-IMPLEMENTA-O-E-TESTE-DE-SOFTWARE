package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class PagamentoServiceTest {
    @ParameterizedTest @CsvSource({"0,3,true", "0,3,false", "1,3,true", "1,3,false", "2,3,true", "3,3,false", "1,1,false", "2,2,false"})
    void tentativas(int falhas,int limite,boolean resposta) {
        List<Long> chamadas=new ArrayList<>();
        PagamentoService s=new PagamentoService(total -> {
            chamadas.add(total);
            if(chamadas.size()<=falhas) throw new IllegalStateException("temporaria");
            return resposta;
        });
        assertEquals(falhas<limite && resposta,s.pagar(12345,limite));
        assertEquals(Collections.nCopies(Math.min(falhas+1,limite),12345L),chamadas);
    }
    @Test void validacoesAntesDaCobranca() {
        List<Long> chamadas=new ArrayList<>();
        PagamentoService s=new PagamentoService(t -> {chamadas.add(t);return true;});
        for(long t : new long[]{-1,0}) assertThrows(IllegalArgumentException.class, () -> s.pagar(t,3));
        for(int n : new int[]{-1,0,4}) assertThrows(IllegalArgumentException.class, () -> s.pagar(1,n));
        assertTrue(chamadas.isEmpty());
        assertThrows(NullPointerException.class, () -> new PagamentoService(null));
    }
    @Test void propagaOutraExcecaoSemRepetir() {
        List<Long> chamadas=new ArrayList<>(); RuntimeException erro=new IllegalArgumentException("definitiva");
        PagamentoService s=new PagamentoService(t -> {chamadas.add(t);throw erro;});
        assertSame(erro,assertThrows(IllegalArgumentException.class, () -> s.pagar(1,3)));
        assertEquals(List.of(1L),chamadas);
    }
}
