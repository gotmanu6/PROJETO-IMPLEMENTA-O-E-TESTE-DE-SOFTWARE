# Relatório — Central de Pedidos

## Escopo e reprodução

Implementação inspecionada em `src/main/java/br/edu/ifpr/pedidos`. Testes em `src/test/java/br/edu/ifpr/pedidos`. Valores monetários deste relatório estão em **centavos**, salvo indicação explícita. As regras de produção e o pom.xml original foram preservados.

Ambiente da execução: Windows, Maven 3.9.11, OpenJDK/JBR 25.0.3, compilação com release 17 do pom, JUnit Jupiter 5.11.4 e JaCoCo 0.8.13. JDK 17 ou superior e Maven 3.9+ permitem reproduzir.

~~~sh
cd aulas/SEMANA06/central-pedidos
mvn clean test
~~~

Resultado final: **85 testes, 0 falhas, 0 erros, 0 ignorados; BUILD SUCCESS**. Abrir [JaCoCo HTML](target/site/jacoco/index.html); contadores em [XML](target/site/jacoco/jacoco.xml) e [CSV](target/site/jacoco/jacoco.csv); resultados individuais em target/surefire-reports. Os logs históricos ficam em evidencias.

## Relacionamentos e grafo de chamadas

~~~mermaid
flowchart TD
 PS[PedidoService.fechar] --> VA[Objects.requireNonNull]
 PS --> CL[Cliente: bloqueio e histórico]
 PS --> SUB[Pedido.subtotalCentavos]
 SUB --> IT[ItemPedido.totalCentavos]
 PS --> ES[Pedido.estoqueSuficiente]
 ES --> DI[ItemPedido.disponivel]
 PS --> DE[PoliticaDesconto.calcular]
 PS --> FR[CalculadoraFrete.calcular]
 FR --> PE[Pedido.pesoGramas]
 FR --> TF[Pedido.temFragil]
 PS --> RI[AnaliseRisco.avaliar]
 PS --> PA[PagamentoService.pagar]
 PA --> PP[ProcessadorPagamento.autorizar: stub]
 PS --> SC[semCobranca]
 SC --> RE[ResultadoPedido]
 PS --> RE
~~~

Pedido contém uma lista de ItemPedido copiada defensivamente. Cliente, ItemPedido, Pedido e ResultadoPedido são records. PedidoService cria os três colaboradores de cálculo/risco e injeta o processador no PagamentoService. O processador é a única dependência externa; os testes usam lambdas locais que registram argumentos e controlam falhas.

## Modelo dos CFGs

Cada operando de && e || é uma decisão separada: uma expressão à direita só aparece quando avaliada. Cada grafo possui entrada I e saída F unificada, incluindo returns e throws representados. Arestas não rotuladas são sequenciais; S/N significa verdadeiro/falso. Switch usa sucessores distintos, unificando SP/RJ por compartilharem o bloco. Sequências sem decisões são agrupadas em blocos.

Exceções explicitamente lançadas pelas guardas entram como saídas. Chamadas são opacas, sem expandir exceções implícitas; em pagar, excepcionalmente, modelamos também a exceção capturada e a propagada de autorizar, pois são o foco do try/catch. Portanto seu V(G) ampliado difere do JaCoCo. Não se misturam contagens de grafos com convenções diferentes.

Cada rota abaixo é uma sequência completa de nós. A independência foi verificada pela matriz de incidência **caminho × aresta**, contando repetições de arestas nos laços: o posto obtido é igual a V(G) em cada base. Não foi inferida independência apenas a partir de percentuais de cobertura.

| Método | Nós N | Arestas E | E − N + 2 | Caminhos / posto | JaCoCo Cxty | Restrições |
| --- | ---: | ---: | ---: | --- | ---: | --- |
| PoliticaDesconto.calcular | 22 | 32 | 32 − 22 + 2 = **12** | 12 / 12 | 12 | Bases abaixo viáveis no domínio unitário |
| CalculadoraFrete.calcular | 21 | 29 | 29 − 21 + 2 = **10** | 10 / 10 | 10 | Normal e expresso não podem ser simultâneos |
| AnaliseRisco.avaliar | 13 | 19 | 19 − 13 + 2 = **8** | 8 / 8 | 8 | Bases abaixo viáveis no domínio unitário |
| PagamentoService.pagar | 14 | 19 | 19 − 14 + 2 = **7** | 7 / 7 | 5 | Após validação, ao menos 1 tentativa |
| PedidoService.fechar | 18 | 22 | 22 − 18 + 2 = **6** | 6 / 6 | 6 | Bloqueio impede RECUSADO no risco |

### PoliticaDesconto.calcular

~~~mermaid
flowchart TD
  I["I: Entrada"]
  N{"N: subtotal < 0?"}
  X["X: Lançar IllegalArgumentException"]
  V{"V: VIP?"}
  A["A: desconto = 10%"]
  S{"S: subtotal >= 50000?"}
  B["B: desconto = 5%"]
  Z["Z: desconto = 0"]
  U{"U: cupom == null?"}
  W{"W: cupom.isBlank()?"}
  R["R: Retornar desconto básico"]
  K["K: switch cupom normalizado"]
  H{"H: compras == 0?"}
  L{"L: subtotal >= 10000?"}
  D["D: Somar 2000"]
  J{"J: subtotal >= 20000?"}
  Q["Q: Somar 10%"]
  T["T: Calcular teto de 20%"]
  C{"C: desconto > teto?"}
  RT["RT: Retornar teto"]
  RD["RD: Retornar desconto"]
  F["F: Saída unificada"]
  I --> N
  N -->|"S"| X
  N -->|"N"| V
  X --> F
  V -->|"S"| A
  V -->|"N"| S
  A --> U
  S -->|"S"| B
  S -->|"N"| Z
  B --> U
  Z --> U
  U -->|"S"| R
  U -->|"N"| W
  W -->|"S"| R
  W -->|"N"| K
  R --> F
  K -->|"BEMVINDO"| H
  K -->|"EXTRA10"| J
  K -->|"desconhecido"| X
  H -->|"S"| L
  H -->|"N"| T
  L -->|"S"| D
  L -->|"N"| T
  D --> T
  J -->|"S"| Q
  J -->|"N"| T
  Q --> T
  T --> C
  C -->|"S"| RT
  C -->|"N"| RD
  RT --> F
  RD --> F
~~~

**Contagem:** N=22; E=32; V(G)=12. 

| ID | Entrada → resultado esperado | Caminho independente | Método JUnit (classe correspondente) |
| --- | --- | --- | --- |
| D1 | comum, 1 compra, subtotal 0, cupom null → 0 | `I → N → V → S → Z → U → R → F` | PoliticaDescontoTest.regrasELimites |
| D2 | subtotal -1 → exceção | `I → N → X → F` | PoliticaDescontoTest.rejeitaSubtotalECupom |
| D3 | VIP, 1 compra, 10009, null → 1000 | `I → N → V → A → U → R → F` | PoliticaDescontoTest.regrasELimites |
| D4 | comum, 1 compra, 50000, null → 2500 | `I → N → V → S → B → U → R → F` | PoliticaDescontoTest.regrasELimites |
| D5 | comum, 1 compra, 50000, branco → 2500 | `I → N → V → S → B → U → W → R → F` | PoliticaDescontoTest.regrasELimites |
| D6 | comum, 1 compra, 10000, ABC → exceção | `I → N → V → S → Z → U → W → K → X → F` | PoliticaDescontoTest.rejeitaSubtotalECupom |
| D7 | comum, 1 compra, 10000, BEMVINDO → 0 | `I → N → V → S → Z → U → W → K → H → T → C → RD → F` | PoliticaDescontoTest.regrasELimites |
| D8 | comum, 0 compras, 9999, BEMVINDO → 0 | `I → N → V → S → Z → U → W → K → H → L → T → C → RD → F` | PoliticaDescontoTest.regrasELimites |
| D9 | comum, 0 compras, 10000, BEMVINDO → 2000 | `I → N → V → S → Z → U → W → K → H → L → D → T → C → RD → F` | PoliticaDescontoTest.regrasELimites |
| D10 | VIP, 0 compras, 10000, BEMVINDO → 2000 (teto) | `I → N → V → A → U → W → K → H → L → D → T → C → RT → F` | PoliticaDescontoTest.regrasELimites |
| D11 | comum, 1 compra, 19999, EXTRA10 → 0 | `I → N → V → S → Z → U → W → K → J → T → C → RD → F` | PoliticaDescontoTest.regrasELimites |
| D12 | comum, 1 compra, 20000, EXTRA10 → 2000 | `I → N → V → S → Z → U → W → K → J → Q → T → C → RD → F` | PoliticaDescontoTest.regrasELimites |

### CalculadoraFrete.calcular

~~~mermaid
flowchart TD
  I["I: Entrada"]
  N{"N: liquido < 0?"}
  X["X: Lançar IllegalArgumentException"]
  S["S: switch UF"]
  PR["PR: base = 1200"]
  SR["SR: base = 2000 (SP ou RJ)"]
  OU["OU: base = 3000"]
  A["A: excedente = peso - 2000"]
  L{"L: excedente > 0?"}
  B["B: frete += 300; excedente -= 1000"]
  G{"G: liquido >= 30000?"}
  E{"E: entrega normal?"}
  Z["Z: frete = 0"]
  V{"V: VIP?"}
  M["M: frete /= 2"]
  EX{"EX: expresso?"}
  AD["AD: frete += 1500"]
  FR{"FR: temFragil?"}
  AF["AF: frete += 500"]
  R["R: Retornar frete"]
  F["F: Saída unificada"]
  I --> N
  N -->|"S"| X
  X --> F
  N -->|"N"| S
  S -->|"PR"| PR
  S -->|"SP ou RJ"| SR
  S -->|"demais"| OU
  PR --> A
  SR --> A
  OU --> A
  A --> L
  L -->|"S"| B
  B --> L
  L -->|"N"| G
  G -->|"S"| E
  G -->|"N"| V
  E -->|"S"| Z
  E -->|"N"| V
  Z --> V
  V -->|"S"| M
  V -->|"N"| EX
  M --> EX
  EX -->|"S"| AD
  EX -->|"N"| FR
  AD --> FR
  FR -->|"S"| AF
  FR -->|"N"| R
  AF --> R
  R --> F
~~~

**Contagem:** N=21; E=29; V(G)=10. SP e RJ convergem ao mesmo bloco, portanto representam uma única saída estrutural do switch; ambos são testados. E significa !pedido.expresso(). E=verdadeiro seguido de EX=verdadeiro é inviável para um Pedido imutável, mas a base abaixo usa somente caminhos viáveis. A presença de G=falso permite separar as contribuições das duas decisões relacionadas a expresso.

| ID | Entrada → resultado esperado | Caminho independente | Método JUnit (classe correspondente) |
| --- | --- | --- | --- |
| F1 | PR, peso 2000, líquido 29999, normal, comum, não frágil → 1200 | `I → N → S → PR → A → L → G → V → EX → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F2 | líquido -1 → exceção | `I → N → X → F` | CalculadoraFreteTest.rejeitaLiquidoNegativo |
| F3 | SP, peso 1000, líquido 0, normal, comum, não frágil → 2000 | `I → N → S → SR → A → L → G → V → EX → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F4 | ZZ, peso 1000, líquido 0, normal, comum, não frágil → 3000 | `I → N → S → OU → A → L → G → V → EX → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F5 | PR, peso 2001, líquido 0, normal, comum, não frágil → 1500 | `I → N → S → PR → A → L → B → L → G → V → EX → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F6 | PR, peso 4500, líquido 30000, normal, comum, não frágil → 0 | `I → N → S → PR → A → L → B → L → B → L → B → L → G → E → Z → V → EX → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F7 | PR, peso 1000, líquido 0, normal, VIP, não frágil → 600 | `I → N → S → PR → A → L → G → V → M → EX → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F8 | PR, peso 1000, líquido 0, expresso, comum, não frágil → 2700 | `I → N → S → PR → A → L → G → V → EX → AD → FR → R → F` | CalculadoraFreteTest.tarifasELimites |
| F9 | PR, peso 1000, líquido 0, normal, comum, frágil → 1700 | `I → N → S → PR → A → L → G → V → EX → FR → AF → R → F` | CalculadoraFreteTest.tarifasELimites |
| F10 | PR, peso 4500, líquido 30000, expresso, VIP, frágil → 3050 | `I → N → S → PR → A → L → B → L → B → L → B → L → G → E → V → M → EX → AD → FR → AF → R → F` | CalculadoraFreteTest.tarifasELimites |

### AnaliseRisco.avaliar

~~~mermaid
flowchart TD
  I["I: Entrada"]
  N{"N: total < 0?"}
  X["X: Lançar IllegalArgumentException"]
  B{"B: bloqueado?"}
  RC["RC: Retornar RECUSADO"]
  C{"C: compras == 0?"}
  T{"T: total > 100000?"}
  E{"E: expresso?"}
  A{"A: total > 500000?"}
  V{"V: não VIP?"}
  RV["RV: Retornar REVISAO"]
  RA["RA: Retornar APROVADO"]
  F["F: Saída unificada"]
  I --> N
  N -->|"S"| X
  X --> F
  N -->|"N"| B
  B -->|"S"| RC
  RC --> F
  B -->|"N"| C
  C -->|"S"| T
  C -->|"N"| A
  T -->|"S"| RV
  T -->|"N"| E
  E -->|"S"| RV
  E -->|"N"| RA
  A -->|"S"| V
  A -->|"N"| RA
  V -->|"S"| RV
  V -->|"N"| RA
  RV --> F
  RA --> F
~~~

**Contagem:** N=13; E=19; V(G)=8. 

| ID | Entrada → resultado esperado | Caminho independente | Método JUnit (classe correspondente) |
| --- | --- | --- | --- |
| R1 | total -1, bloqueado → exceção | `I → N → X → F` | AnaliseRiscoTest.negativoAntesDoBloqueio |
| R2 | bloqueado, total 0 → RECUSADO | `I → N → B → RC → F` | AnaliseRiscoTest.regrasELimites |
| R3 | novo, total 100001, normal → REVISAO | `I → N → B → C → T → RV → F` | AnaliseRiscoTest.regrasELimites |
| R4 | novo, total 0, expresso → REVISAO | `I → N → B → C → T → E → RV → F` | AnaliseRiscoTest.regrasELimites |
| R5 | novo, total 100000, normal → APROVADO | `I → N → B → C → T → E → RA → F` | AnaliseRiscoTest.regrasELimites |
| R6 | antigo, total 500000, comum → APROVADO | `I → N → B → C → A → RA → F` | AnaliseRiscoTest.regrasELimites |
| R7 | antigo, total 500001, comum → REVISAO | `I → N → B → C → A → V → RV → F` | AnaliseRiscoTest.regrasELimites |
| R8 | antigo, total 500001, VIP → APROVADO | `I → N → B → C → A → V → RA → F` | AnaliseRiscoTest.regrasELimites |

### PagamentoService.pagar

~~~mermaid
flowchart TD
  I["I: Entrada"]
  T{"T: total <= 0?"}
  X["X: Lançar IllegalArgumentException"]
  L{"L: maxTentativas < 1?"}
  U{"U: maxTentativas > 3?"}
  Z["Z: tentativa = 0"]
  A["A: tentativa++"]
  P["P: autorizar(total)"]
  R["R: Retornar booleano recebido"]
  C["C: catch IllegalStateException"]
  W{"W: tentativa < maxTentativas?"}
  RF["RF: Retornar false"]
  O["O: Propagar outra exceção"]
  F["F: Saída unificada"]
  I --> T
  T -->|"S"| X
  X --> F
  T -->|"N"| L
  L -->|"S"| X
  L -->|"N"| U
  U -->|"S"| X
  U -->|"N"| Z
  Z --> A
  A --> P
  P -->|"retorno normal"| R
  R --> F
  P -->|"IllegalStateException"| C
  P -->|"outra exceção"| O
  O --> F
  C --> W
  W -->|"S"| A
  W -->|"N"| RF
  RF --> F
~~~

**Contagem:** N=14; E=19; V(G)=7. Este CFG inclui explicitamente as três saídas de autorizar: retorno normal, exceção capturada e exceção propagada. Não há decisão true/false dentro de pagar: o booleano é retornado diretamente. O JaCoCo não conta as duas alternativas excepcionais de P; sua complexidade é 5, enquanto este grafo aumentado tem V(G)=7. O do/while não admite zero tentativas após validação: zero chamadas só ocorre na validação.

| ID | Entrada → resultado esperado | Caminho independente | Método JUnit (classe correspondente) |
| --- | --- | --- | --- |
| P1 | total 0, limite 3 → exceção; zero cobranças | `I → T → X → F` | PagamentoServiceTest.validacoesAntesDaCobranca |
| P2 | total 1, limite 0 → exceção; zero cobranças | `I → T → L → X → F` | PagamentoServiceTest.validacoesAntesDaCobranca |
| P3 | total 1, limite 4 → exceção; zero cobranças | `I → T → L → U → X → F` | PagamentoServiceTest.validacoesAntesDaCobranca |
| P4 | total 12345, limite 3, true → true; 1 chamada | `I → T → L → U → Z → A → P → R → F` | PagamentoServiceTest.tentativas |
| P5 | total 12345, limite 1, IllegalStateException → false; 1 chamada | `I → T → L → U → Z → A → P → C → W → RF → F` | PagamentoServiceTest.tentativas |
| P6 | total 12345, limite 3, exceção temporária e true → true; 2 chamadas | `I → T → L → U → Z → A → P → C → W → A → P → R → F` | PagamentoServiceTest.tentativas |
| P7 | total 1, limite 3, IllegalArgumentException → propaga mesma instância; 1 chamada | `I → T → L → U → Z → A → P → O → F` | PagamentoServiceTest.propagaOutraExcecaoSemRepetir |

### PedidoService.fechar

~~~mermaid
flowchart TD
  I["I: Entrada"]
  Q["Q: requireNonNull(pedido e cliente)"]
  B{"B: bloqueado?"}
  RB["RB: semCobranca(BLOQUEADO)"]
  S["S: subtotalCentavos()"]
  Z{"Z: subtotal == 0?"}
  X["X: Lançar IllegalArgumentException"]
  E{"E: estoque suficiente?"}
  RE["RE: semCobranca(SEM_ESTOQUE)"]
  D["D: desconto; liquido; frete; total"]
  A["A: risco.avaliar()"]
  V{"V: análise diferente de APROVADO?"}
  RV["RV: Retornar resultado com análise e valores"]
  P{"P: pagamentos.pagar(total,3)?"}
  OK["OK: status = PAGO"]
  NO["NO: status = PAGAMENTO_RECUSADO"]
  R["R: Retornar resultado com valores"]
  F["F: Saída unificada"]
  I --> Q
  Q --> B
  B -->|"S"| RB
  RB --> F
  B -->|"N"| S
  S --> Z
  Z -->|"S"| X
  X --> F
  Z -->|"N"| E
  E -->|"N"| RE
  RE --> F
  E -->|"S"| D
  D --> A
  A --> V
  V -->|"S"| RV
  RV --> F
  V -->|"N"| P
  P -->|"S"| OK
  P -->|"N"| NO
  OK --> R
  NO --> R
  R --> F
~~~

**Contagem:** N=18; E=22; V(G)=6. Este CFG é intraprocedural: Q e chamadas colaboradoras são blocos opacos; saídas excepcionais implícitas dessas chamadas não entram na contagem. Nulos, cupom inválido e propagação do processador são testes adicionais documentados na matriz. O risco RECUSADO é inviável por fechar: o bloqueio já retorna em B. Risco negativo também é inviável pelo domínio válido e desconto limitado.

| ID | Entrada → resultado esperado | Caminho independente | Método JUnit (classe correspondente) |
| --- | --- | --- | --- |
| S1 | comum, 10000, disponível, PR normal, stub true → PAGO (10000,0,1200,11200), 1 cobrança | `I → Q → B → S → Z → E → D → A → V → P → OK → R → F` | PedidoServiceTest.pagamentoImediato |
| S2 | mesmos dados, stub false → PAGAMENTO_RECUSADO, mesmos valores, 1 cobrança | `I → Q → B → S → Z → E → D → A → V → P → NO → R → F` | PedidoServiceTest.pagamentoImediato |
| S3 | bloqueado, pedido vazio e cupom inválido → BLOQUEADO, zeros, zero cobranças | `I → Q → B → RB → F` | PedidoServiceTest.bloqueioAntesDeSubtotalEstoqueECupom |
| S4 | desbloqueado, lista vazia → exceção, zero cobranças | `I → Q → B → S → Z → X → F` | PedidoServiceTest.validacoesEInterrupcoesSemCobranca |
| S5 | quantidade 5, estoque 4, cupom ABC → SEM_ESTOQUE, zeros, zero cobranças | `I → Q → B → S → Z → E → RE → F` | PedidoServiceTest.estoqueAntesDoCupom |
| S6 | novo, subtotal 200000, normal → REVISAO (200000,10000,0,190000), zero cobranças | `I → Q → B → S → Z → E → D → A → V → RV → F` | PedidoServiceTest.revisaoSemCobranca |

## Matriz de testes

As tabelas das bases acima também identificam entrada, oráculo, caminho e método JUnit. Esta matriz consolida esses casos e completa os critérios adicionais. Os parâmetros de cada método parametrizado contam como execuções distintas no Surefire.

| ID / método JUnit | Unidade | Entrada e estado do stub | Resultado esperado | Caminho / aresta | Critério atendido |
| --- | --- | --- | --- | --- | --- |
| D1 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 1 compra, subtotal 0, cupom null | 0 | I → N → V → S → Z → U → R → F | Caminho da base; decisões e retornos |
| D2 / PoliticaDescontoTest.rejeitaSubtotalECupom | PoliticaDesconto.calcular | subtotal -1 | exceção | I → N → X → F | Caminho da base; decisões e retornos |
| D3 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | VIP, 1 compra, 10009, null | 1000 | I → N → V → A → U → R → F | Caminho da base; decisões e retornos |
| D4 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 1 compra, 50000, null | 2500 | I → N → V → S → B → U → R → F | Caminho da base; decisões e retornos |
| D5 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 1 compra, 50000, branco | 2500 | I → N → V → S → B → U → W → R → F | Caminho da base; decisões e retornos |
| D6 / PoliticaDescontoTest.rejeitaSubtotalECupom | PoliticaDesconto.calcular | comum, 1 compra, 10000, ABC | exceção | I → N → V → S → Z → U → W → K → X → F | Caminho da base; decisões e retornos |
| D7 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 1 compra, 10000, BEMVINDO | 0 | I → N → V → S → Z → U → W → K → H → T → C → RD → F | Caminho da base; decisões e retornos |
| D8 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 0 compras, 9999, BEMVINDO | 0 | I → N → V → S → Z → U → W → K → H → L → T → C → RD → F | Caminho da base; decisões e retornos |
| D9 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 0 compras, 10000, BEMVINDO | 2000 | I → N → V → S → Z → U → W → K → H → L → D → T → C → RD → F | Caminho da base; decisões e retornos |
| D10 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | VIP, 0 compras, 10000, BEMVINDO | 2000 (teto) | I → N → V → A → U → W → K → H → L → D → T → C → RT → F | Caminho da base; decisões e retornos |
| D11 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 1 compra, 19999, EXTRA10 | 0 | I → N → V → S → Z → U → W → K → J → T → C → RD → F | Caminho da base; decisões e retornos |
| D12 / PoliticaDescontoTest.regrasELimites | PoliticaDesconto.calcular | comum, 1 compra, 20000, EXTRA10 | 2000 | I → N → V → S → Z → U → W → K → J → Q → T → C → RD → F | Caminho da base; decisões e retornos |
| F1 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 2000, líquido 29999, normal, comum, não frágil | 1200 | I → N → S → PR → A → L → G → V → EX → FR → R → F | Caminho da base; decisões e retornos |
| F2 / CalculadoraFreteTest.rejeitaLiquidoNegativo | CalculadoraFrete.calcular | líquido -1 | exceção | I → N → X → F | Caminho da base; decisões e retornos |
| F3 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | SP, peso 1000, líquido 0, normal, comum, não frágil | 2000 | I → N → S → SR → A → L → G → V → EX → FR → R → F | Caminho da base; decisões e retornos |
| F4 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | ZZ, peso 1000, líquido 0, normal, comum, não frágil | 3000 | I → N → S → OU → A → L → G → V → EX → FR → R → F | Caminho da base; decisões e retornos |
| F5 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 2001, líquido 0, normal, comum, não frágil | 1500 | I → N → S → PR → A → L → B → L → G → V → EX → FR → R → F | Caminho da base; decisões e retornos |
| F6 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 4500, líquido 30000, normal, comum, não frágil | 0 | I → N → S → PR → A → L → B → L → B → L → B → L → G → E → Z → V → EX → FR → R → F | Caminho da base; decisões e retornos |
| F7 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 1000, líquido 0, normal, VIP, não frágil | 600 | I → N → S → PR → A → L → G → V → M → EX → FR → R → F | Caminho da base; decisões e retornos |
| F8 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 1000, líquido 0, expresso, comum, não frágil | 2700 | I → N → S → PR → A → L → G → V → EX → AD → FR → R → F | Caminho da base; decisões e retornos |
| F9 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 1000, líquido 0, normal, comum, frágil | 1700 | I → N → S → PR → A → L → G → V → EX → FR → AF → R → F | Caminho da base; decisões e retornos |
| F10 / CalculadoraFreteTest.tarifasELimites | CalculadoraFrete.calcular | PR, peso 4500, líquido 30000, expresso, VIP, frágil | 3050 | I → N → S → PR → A → L → B → L → B → L → B → L → G → E → V → M → EX → AD → FR → AF → R → F | Caminho da base; decisões e retornos |
| R1 / AnaliseRiscoTest.negativoAntesDoBloqueio | AnaliseRisco.avaliar | total -1, bloqueado | exceção | I → N → X → F | Caminho da base; decisões e retornos |
| R2 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | bloqueado, total 0 | RECUSADO | I → N → B → RC → F | Caminho da base; decisões e retornos |
| R3 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | novo, total 100001, normal | REVISAO | I → N → B → C → T → RV → F | Caminho da base; decisões e retornos |
| R4 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | novo, total 0, expresso | REVISAO | I → N → B → C → T → E → RV → F | Caminho da base; decisões e retornos |
| R5 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | novo, total 100000, normal | APROVADO | I → N → B → C → T → E → RA → F | Caminho da base; decisões e retornos |
| R6 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | antigo, total 500000, comum | APROVADO | I → N → B → C → A → RA → F | Caminho da base; decisões e retornos |
| R7 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | antigo, total 500001, comum | REVISAO | I → N → B → C → A → V → RV → F | Caminho da base; decisões e retornos |
| R8 / AnaliseRiscoTest.regrasELimites | AnaliseRisco.avaliar | antigo, total 500001, VIP | APROVADO | I → N → B → C → A → V → RA → F | Caminho da base; decisões e retornos |
| P1 / PagamentoServiceTest.validacoesAntesDaCobranca | PagamentoService.pagar | total 0, limite 3 | exceção; zero cobranças | I → T → X → F | Caminho da base; decisões e retornos |
| P2 / PagamentoServiceTest.validacoesAntesDaCobranca | PagamentoService.pagar | total 1, limite 0 | exceção; zero cobranças | I → T → L → X → F | Caminho da base; decisões e retornos |
| P3 / PagamentoServiceTest.validacoesAntesDaCobranca | PagamentoService.pagar | total 1, limite 4 | exceção; zero cobranças | I → T → L → U → X → F | Caminho da base; decisões e retornos |
| P4 / PagamentoServiceTest.tentativas | PagamentoService.pagar | total 12345, limite 3, true | true; 1 chamada | I → T → L → U → Z → A → P → R → F | Caminho da base; decisões e retornos |
| P5 / PagamentoServiceTest.tentativas | PagamentoService.pagar | total 12345, limite 1, IllegalStateException | false; 1 chamada | I → T → L → U → Z → A → P → C → W → RF → F | Caminho da base; decisões e retornos |
| P6 / PagamentoServiceTest.tentativas | PagamentoService.pagar | total 12345, limite 3, exceção temporária e true | true; 2 chamadas | I → T → L → U → Z → A → P → C → W → A → P → R → F | Caminho da base; decisões e retornos |
| P7 / PagamentoServiceTest.propagaOutraExcecaoSemRepetir | PagamentoService.pagar | total 1, limite 3, IllegalArgumentException | propaga mesma instância; 1 chamada | I → T → L → U → Z → A → P → O → F | Caminho da base; decisões e retornos |
| S1 / PedidoServiceTest.pagamentoImediato | PedidoService.fechar | comum, 10000, disponível, PR normal, stub true | PAGO (10000,0,1200,11200), 1 cobrança | I → Q → B → S → Z → E → D → A → V → P → OK → R → F | Caminho da base; decisões e retornos |
| S2 / PedidoServiceTest.pagamentoImediato | PedidoService.fechar | mesmos dados, stub false | PAGAMENTO_RECUSADO, mesmos valores, 1 cobrança | I → Q → B → S → Z → E → D → A → V → P → NO → R → F | Caminho da base; decisões e retornos |
| S3 / PedidoServiceTest.bloqueioAntesDeSubtotalEstoqueECupom | PedidoService.fechar | bloqueado, pedido vazio e cupom inválido | BLOQUEADO, zeros, zero cobranças | I → Q → B → RB → F | Caminho da base; decisões e retornos |
| S4 / PedidoServiceTest.validacoesEInterrupcoesSemCobranca | PedidoService.fechar | desbloqueado, lista vazia | exceção, zero cobranças | I → Q → B → S → Z → X → F | Caminho da base; decisões e retornos |
| S5 / PedidoServiceTest.estoqueAntesDoCupom | PedidoService.fechar | quantidade 5, estoque 4, cupom ABC | SEM_ESTOQUE, zeros, zero cobranças | I → Q → B → S → Z → E → RE → F | Caminho da base; decisões e retornos |
| S6 / PedidoServiceTest.revisaoSemCobranca | PedidoService.fechar | novo, subtotal 200000, normal | REVISAO (200000,10000,0,190000), zero cobranças | I → Q → B → S → Z → E → D → A → V → RV → F | Caminho da base; decisões e retornos |
| PoliticaDescontoTest.normalizaCupons | Desconto | " bemvindo " com novo e 10000; " extra10 " com antigo e 20000 | 2000 nos dois casos | K→H / K→J | trim e maiúsculas |
| PoliticaDescontoTest.regrasELimites (demais linhas) | Desconto | 49999/50000/50001; 9999/10000/10001; 19999/20000/20001; VIP 10009; VIP EXTRA10 20009; comum EXTRA10 50001 | 0/2500/2500; 0/2000/2000; 0/2000/2000; 1000; 4000; 7500 | S, L, J, C | Limites, teto e truncamento inteiro |
| CalculadoraFreteTest.tarifasELimites (demais linhas) | Frete | RJ; 1999/2000/2001/3000/3001/4500g; líquido 29999/30000/30001 | RJ=2000; pesos PR sem benefícios=1200/1200/1500/1500/1800/2100; líquido normal >=30000 zera base/peso | S→SR; L→B; G→E→Z | Cases, frações, 0/1/2/3 iterações; VIP; expresso; frágil |
| CalculadoraFreteTest.fragilidadeCobradaUmaVez | Frete | Dois itens frágeis ativos, PR, 2g, líquido 0 | 1700 | FR→AF uma vez | Adicional único por pedido |
| AnaliseRiscoTest.regrasELimites (demais linhas) | Risco | Novo 99999/100000/100001 normal; antigo comum 499999/500000/500001; antigo total 0 expresso | APROVADO/APROVADO/REVISAO; APROVADO/APROVADO/REVISAO; APROVADO | T; A; C→A | Limites estritos e separação de cliente novo/antigo |
| PagamentoServiceTest.tentativas (demais linhas) | Pagamento | false imediato; exceção→false; duas exceções→true; 3 exceções/limite3; 2 exceções/limite2 | false/1; false/2; true/3; false/3; false/2; todos argumentos 12345 | P→R; P→C; W→A/RF | Recusa sem repetição; limites 1..3; listas de argumentos |
| PagamentoServiceTest.validacoesAntesDaCobranca | Pagamento | Total -1/0; limites -1/0/4; processador null | IllegalArgumentException nas entradas; NullPointerException no construtor; lista de cobranças vazia | T/L/U→X; construtor | Validação anterior à dependência |
| ClienteTest.historicoValido / historicoNegativo | Cliente | Histórico 0 e 1; -1; indicadores VIP e bloqueio verdadeiros | Campos preservados; IllegalArgumentException para -1 | Construtor aceita/rejeita | Domínio e acessores |
| ItemPedidoTest.limitesInvalidos / skuInvalido | ItemPedido | SKU null/branco; preço 0/1000001; quantidade -1/101; estoque -1; peso 0/100001 | IllegalArgumentException em cada entrada isolada | Cada guarda e operando de // | Validações, curto-circuito |
| ItemPedidoTest.limitesValidosECalculos | ItemPedido | Preço 1/1000000; qtd 0/1/100; peso 1/100000; qtd igual/menor/maior que estoque | Total 0 ou 100000000; disponibilidade true/true/false; campos preservados | totalCentavos; disponivel | Limites aceitos, multiplicação e duas saídas |
| PedidoTest.validaListaEUf | Pedido | Lista null/101 linhas/elemento null; UF null, vazia, P, PRR, pr, P1, ÁB; 100 linhas e ZZ | IllegalArgumentException, exceto elemento null: NullPointerException; 100 linhas/ZZ aceitos | Guardas do construtor | //; tamanho; regex ASCII; cópia |
| PedidoTest.copiaDefensiva | Pedido | Construir com lista mutável, limpar origem e tentar limpar itens() | Pedido mantém 1 item; UnsupportedOperationException ao alterar cópia; campos preservados | List.copyOf | Imutabilidade observável |
| PedidoTest.vazio / umaLinhaInativa | Pedido | [] e uma linha frágil com qtd0 | subtotal=0; peso=0; temFragil=false; estoqueSuficiente=true | for zero/uma vez; continue; curto-circuito | Linha inativa não pesa nem torna frágil |
| PedidoTest.variasLinhasEContinue | Pedido | Qtd 0 frágil, 1 não frágil, 2 frágil, 1 frágil; estoque suficiente | subtotal400; peso4000; frágil=true; estoque=true | continue; for múltiplo; retorno antecipado | Combinações de ativos/inativos |
| PedidoTest.faltaEstoqueInicioEFimESkuRepetido | Pedido | Falta na primeira/última linha; duas linhas mesmo SKU suficientes; uma linha não frágil | false/false/true no estoque; false na fragilidade | break; continuação; retorno false | Estoque independente por linha |
| PedidoTest.maximoDoDominioSemOverflow | Pedido | 100 linhas × 100 unidades; preço1000000; peso100000 | subtotal10000000000L; peso1000000000 | Laços até o limite | long monetário e limite do int de peso |
| PedidoServiceTest.validacoesEInterrupcoesSemCobranca | Fechamento | Dependência/pedido/cliente null; pedido null e bloqueado; lista vazia; linha inativa; cupom ABC com estoque | NPE para null; IAE para subtotal0/cupom; zero cobranças | Q; Z→X; exceção da chamada em D | Ordem, propagação, validação antes de bloqueio |
| PedidoServiceTest.bloqueioAntesDeSubtotalEstoqueECupom | Fechamento | Bloqueado + vazio + ABC; bloqueado + sem estoque + ABC | BLOQUEADO; quatro valores zero; zero cobranças | B→RB | Retorno anterior a subtotal, estoque e cupom |
| PedidoServiceTest.revisaoSemCobranca | Fechamento | Novo200000 normal; novo10000 expresso; antigo600000 normal | REVISAO; (200000,10000,0,190000); (10000,0,2700,12700); (600000,30000,0,570000); zero cobranças | V→RV | Três motivos de revisão via colaboração |
| PedidoServiceTest.falhasTemporarias | Fechamento | 1, 2 ou 3 exceções temporárias antes de true | PAGO/2 chamadas; PAGO/3; PAGAMENTO_RECUSADO/3; valores (10000,0,1200,11200); argumentos11200 | V→P; P→OK/NO | Colaboração com retry e esgotamento |
| PedidoServiceTest.propagaFalhaDoProcessador | Fechamento | Stub lança UnsupportedOperationException | Mesma instância propagada; uma cobrança11200 | Saída excepcional da chamada P | Não repetir outra exceção |
| PedidoServiceTest.colaboracaoDescontoFreteEEntradasImutaveis | Fechamento | VIP antigo, 2×20009, SP, expresso, peso3002g, frágil, EXTRA10 normalizado; fechar duas vezes | PAGO; (40018,8002,3300,35316) em ambas; cobranças[35316,35316]; estoque2 e histórico1 | D→A→V→P→OK | Integração, truncamento, frete e ausência de mutação/idempotência |

## Evolução medida da cobertura

Percentuais extraídos dos XMLs reais de cada execução; frações são coberto/total.

| Etapa | Testes executados | Linhas | Branches | Métodos | Classes | Lacunas e justificativas |
| --- | ---: | --- | --- | --- | --- | --- |
| Inicial: teste original | 1 | 87/108 (80,56%) | 50/116 (43,10%) | 20/21 (95,24%) | 9/9 (100,00%) | Somente fechamento feliz; decisões alternativas, catch e semCobranca ausentes |
| Unidades isoladas, sem PedidoServiceTest | 74 | 85/108 (78,70%) | 106/116 (91,38%) | 17/21 (80,95%) | 7/9 (77,78%) | Execução deliberadamente não cumulativa: PedidoService e ResultadoPedido não são exercitados |
| Final: unidades + colaboração | 85 | 108/108 (100,00%) | 116/116 (100,00%) | 21/21 (100,00%) | 9/9 (100,00%) | Nenhuma linha/branch/método/classe reportável perdida |

A segunda etapa seleciona apenas ClienteTest, ItemPedidoTest, PedidoTest, PoliticaDescontoTest, CalculadoraFreteTest, AnaliseRiscoTest e PagamentoServiceTest. Por isso linhas/métodos/classes podem cair em relação ao exemplo integrado, mesmo com aumento de branches. A etapa final reúne as unidades e 11 execuções de colaboração.

100% de classes significa ao menos um método executado por classe; 100% de métodos significa cada método reportável chamado; linhas indicam instruções associadas a linhas executadas; branches indicam alternativas de decisões executadas. Construtores entram no relatório. JaCoCo filtra métodos gerados de records; ProcessadorPagamento é interface sem implementação executável. São 9 classes concretas e 21 métodos reportáveis, sem exclusões adicionadas ao pom. A cobertura de instruções também foi 637/637 e a complexidade coberta 80/80. Nada disso comprova todos os caminhos, MC/DC ou ausência de defeitos.

## Análise crítica

### Ramos não equivalem a caminhos

No frete, fixe PR, peso1000, líquido0 e não frágil. Dois testes (comum/normal e VIP/expresso) cobrem verdadeiro/falso tanto de VIP quanto de expresso; porém faltam VIP/normal e comum/expresso. Os dois testes cobrem esses ramos, não todo o método. Mesmo em uma suíte com 100% de branches do método, combinações como RJ + VIP + expresso + frágil podem permanecer ausentes. A suíte entregue acrescenta VIP/normal, comum/expresso e várias combinações, mas não promete enumerar todas.

O exemplo completo mais simples está no outro exercício: Participacao(V,V) e Participacao(F,F) atingem 100% de seus ramos, mas deixam (V,F) e (F,V) sem execução. A suíte do Boletim testa as quatro combinações. V(G)=3, embora existam quatro caminhos completos: tamanho da base e número total de caminhos são conceitos distintos.

### Curto-circuito

No desconto, cupom null impede isBlank; histórico diferente de zero impede o teste de subtotal do BEMVINDO. No risco, total novo >100000 impede avaliar expresso, e total antigo <=500000 impede avaliar !VIP. No frete, líquido <30000 impede avaliar !expresso. Em Pedido.temFragil, quantidade0 impede fragil(). Nos construtores, o primeiro operando verdadeiro de || impede o seguinte. Os testes incluem condições que fazem cada operando ser avaliado e condições que o pulam.

### Viabilidade e unidade versus colaboração

AnaliseRisco retorna RECUSADO para bloqueados em teste unitário, mas PedidoService retorna BLOQUEADO antes de chamá-la. Não se deve alterar produção para tentar obter RECUSADO via fechar. No domínio válido, subtotal é não negativo, desconto nunca excede subtotal e frete é não negativo; assim, as guardas monetárias negativas das unidades não são alcançadas pelo fluxo normal do serviço. Cupom desconhecido após bloqueio ou falta de estoque também não é avaliado. No frete, a mesma entrega não pode ser normal numa decisão e expressa na seguinte. Esses caminhos sintáticos inviáveis não impediram formar as bases viáveis apresentadas.

### Laços e exceções

Pedido foi exercitado com lista vazia, uma linha ativa/inativa e várias linhas; continue pula item inativo e break encerra estoque na primeira falta, testada no início e no fim. No peso excedente, 1999/2000g dão zero iterações, 2001/3000g dão uma, 3001g dão duas e 4500g dão três; o peso total leva quantidade em conta.

Pagamento usa do/while: uma tentativa em sucesso/recusa imediatos, duas e três com indisponibilidades, e limites 1, 2 e 3 no esgotamento. O stub registra a lista completa de valores cobrados para verificar número, ordem e argumentos. IllegalStateException produz retry, enquanto outra RuntimeException é propagada por identidade, sem repetição.

**Exceção que não aparece como branch:** a transição de autorizar para catch(IllegalStateException). O teste tentativas com uma falha seguida de sucesso exercita esse tratamento. JaCoCo conta a decisão do while e as guardas, mas não a aresta excepcional do try/catch. Por isso 100% de branches não bastaria como evidência de que o catch foi testado; usamos resultado, chamadas e cobertura de linhas. IllegalArgumentException das guardas também é testada, porém sua decisão if é contabilizada normalmente.

### Alteração proposital e restauração

Em AnaliseRisco, alterou-se temporariamente **total > 100_000** para **total >= 100_000**. Executou-se mvn -Dtest=AnaliseRiscoTest clean test. Resultado real: 11 testes, **1 falha**, 0 erros; regrasELimites para cliente novo, total100000, normal esperava APROVADO e recebeu REVISAO. Log: [evidencias/mutacao.log](evidencias/mutacao.log).

A alteração foi desfeita restaurando os bytes originais. Depois, mvn clean test executou novamente os 85 testes com sucesso. A comparação dos arquivos src/main com o ZIP original confirma preservação integral, registrada em evidencias/integridade-producao.txt. Os relatórios em target são os da execução final restaurada, não os da mutação.

## Evidências incluídas

- evidencias/inicial.log e inicial-jacoco.xml: teste original.
- evidencias/unitarios.log e unitarios-jacoco.xml: execução isolada das unidades.
- evidencias/mutacao.log: falha proposital detectada.
- evidencias/final.log: execução final após restauração.
- evidencias/grafos.json: nós, arestas, rotas, contagens e postos das bases.
- evidencias/integridade-producao.txt: comparação com o anexo original.

Os README.md originais continuam sendo os enunciados. A implementação final e este relatório substituem os espaços de exercício, preservando os contratos originais.
