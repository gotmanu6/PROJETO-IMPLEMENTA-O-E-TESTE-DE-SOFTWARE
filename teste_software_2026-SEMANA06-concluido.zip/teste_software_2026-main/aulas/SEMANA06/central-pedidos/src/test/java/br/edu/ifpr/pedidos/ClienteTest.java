package br.edu.ifpr.pedidos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class ClienteTest {
    @Test void historicoValido() {
        Cliente c=new Cliente(true,true,0);
        assertTrue(c.vip()); assertTrue(c.bloqueado()); assertEquals(0,c.comprasAnteriores());
        assertEquals(1,new Cliente(false,false,1).comprasAnteriores());
    }
    @Test void historicoNegativo() { assertThrows(IllegalArgumentException.class, () -> new Cliente(false,false,-1)); }
}
