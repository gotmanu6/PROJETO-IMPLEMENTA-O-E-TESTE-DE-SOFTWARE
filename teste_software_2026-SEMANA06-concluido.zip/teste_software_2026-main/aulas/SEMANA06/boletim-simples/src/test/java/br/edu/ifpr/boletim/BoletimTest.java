package br.edu.ifpr.boletim;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class BoletimTest {
    private final Boletim boletim = new Boletim();
    @ParameterizedTest @CsvSource({"8,6,7", "8.5,7,7.75", "0,0,0", "10,10,10"})
    void medias(double a, double b, double esperado) {
        assertEquals(esperado, boletim.calcularMedia(a,b), 0.0001);
    }
    @ParameterizedTest @CsvSource({"0,REPROVADO", "3.99,REPROVADO", "4,RECUPERACAO", "4.01,RECUPERACAO", "6.99,RECUPERACAO", "7,APROVADO", "7.01,APROVADO", "10,APROVADO"})
    void situacoesELimites(double media, String esperado) {
        assertEquals(esperado, boletim.verificarSituacao(media));
    }
    @Test void lacoVazio() { assertEquals(0, boletim.contarAprovados(new double[]{})); }
    @Test void lacoUmaIteracao() {
        assertEquals(1, boletim.contarAprovados(new double[]{7}));
        assertEquals(0, boletim.contarAprovados(new double[]{6.99}));
    }
    @Test void lacoVariasIteracoes() {
        assertEquals(3, boletim.contarAprovados(new double[]{8,5,7,3,9}));
    }
}
