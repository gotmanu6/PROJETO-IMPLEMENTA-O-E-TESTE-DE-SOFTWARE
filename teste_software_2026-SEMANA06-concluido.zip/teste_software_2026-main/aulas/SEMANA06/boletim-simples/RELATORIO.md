# Relatório — Boletim simples

## Execução

Foram inspecionadas Boletim e Participacao. Produção e pom originais preservados. Ambiente: Maven3.9.11, OpenJDK/JBR25.0.3, release17, JUnit5.11.4, JaCoCo0.8.13.

~~~sh
cd aulas/SEMANA06/boletim-simples
mvn clean test
~~~

**19 testes, 0 falhas, 0 erros, 0 ignorados; BUILD SUCCESS.** Abrir [JaCoCo](target/site/jacoco/index.html). XML e CSV acompanham o HTML; Surefire está em target/surefire-reports.

## Casos e resultados

| Método JUnit | Unidade | Entradas | Resultados esperados | Critério |
| --- | --- | --- | --- | --- |
| BoletimTest.medias | Boletim | (8,6), (8.5,7), (0,0), (10,10) | 7; 7,75; 0; 10, tolerância 0,0001 | Sequência sem decisão; média decimal |
| BoletimTest.situacoesELimites | Boletim | 0; 3,99; 4; 4,01; 6,99; 7; 7,01; 10 | REPROVADO; REPROVADO; RECUPERACAO; RECUPERACAO; RECUPERACAO; APROVADO; APROVADO; APROVADO | Três caminhos e fronteiras |
| BoletimTest.lacoVazio / lacoUmaIteracao / lacoVariasIteracoes | Boletim | []; [7]; [6,99]; [8,5,7,3,9] | 0; 1; 0; 3 | 0, 1 e várias iterações |
| ParticipacaoTest.quatroCaminhos | Participacao | VV; VF; FV; FF | 3; 2; 1; 0 | Quatro caminhos completos |

## Cobertura medida

| Etapa | Testes | Linhas | Branches | Métodos | Classes | Observação |
| --- | ---: | --- | --- | --- | --- | --- |
| Original | 4 | 9/21 (42,86%) | 4/12 (33,33%) | 3/6 (50,00%) | 1/2 (50,00%) | Não executava contagem nem Participacao |
| Final | 19 | 21/21 (100,00%) | 12/12 (100,00%) | 6/6 (100,00%) | 2/2 (100,00%) | Todos os contadores sem perdas |

Classes: ao menos um método de cada classe executado. Métodos: todos os métodos reportáveis chamados, incluindo os dois construtores. Linhas: instruções de cada linha executadas. Branches: alternativas verdadeira/falsa de todas as decisões executadas. Asserções verificam os resultados; cobertura sozinha não prova correção.

## Caminhos

verificarSituacao possui V(G)=3: media>=7 → APROVADO; media<7 e >=4 → RECUPERACAO; media<4 → REPROVADO.

Participacao.calcularPontos possui duas decisões independentes, V(G)=3, e quatro caminhos completos:

| Entregou | Participou | Pontos | Caminho |
| --- | --- | ---: | --- |
| true | true | 3 | soma2 → soma1 |
| true | false | 2 | soma2 → pula1 |
| false | true | 1 | pula2 → soma1 |
| false | false | 0 | pula2 → pula1 |

A base pode usar FF, VF e FV. VV acrescenta o quarto caminho. Apenas VV e FF já cobrem 100% dos branches, mas deixam VF/FV sem execução; a suíte entregue cobre os quatro.

calcularMedia é sequencial (V=1). contarAprovados tem duas decisões (laço e aprovação), V=3. Foram testados zero, uma e várias iterações, incluindo exatamente7 e um valor logo abaixo. Notas permanecem em0..10 e arrays são não nulos, conforme escopo.

## Demonstração de falha e restauração

O esperado de medias(8,6) foi temporariamente alterado de7 para8. A execução de BoletimTest falhou exatamente uma vez: expected8.0 but was7.0 (15 execuções, 1 falha). O teste foi restaurado; mvn clean test voltou a passar os19 testes. Evidências: inicial.log, inicial-jacoco.xml, mutacao.log e final.log em evidencias. A produção não foi alterada.
